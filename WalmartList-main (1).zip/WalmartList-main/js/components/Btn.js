export default {
    template: `
        <button class="btn">
            <span class="type-label-lg">
                <slot></slot>
            </span>
        </button>
    `,
};
